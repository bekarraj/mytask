/*******************************************************************************
11. What will be the output of following code?

class Base{
private:
 int x;
public:
 Base() { x = 0; }
 Base(int p1) { x = p1; }
 void show() { cout<<="" pre="" style="box-sizing: border-box;"> 


Answer : compilation error at cout<<=
*******************************************************************************/
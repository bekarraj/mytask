/*******************************************************************************
8.Consider the classes Manager and Employee. 
Which should be the base class and which should be the derived class?
What type of relationship exists between them?

Ans: According to me, Manager need to manage group of employees
and their work. so we can refer employees as class members and 
their work as class methods. so, we can declare Employee as
base class and manager as derived class. In that way manager will have 
access to all employees(members) and also to their works(methods).
*******************************************************************************/
#include<iostream>// Hader file is not declare in question
using namespace std;
void test(char *str)
{
	cout<<str;
}
main()
{
	test("success");
}

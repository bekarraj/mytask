//Structures HandsOn project 8

1) struct data
{
  char c;
  int x;
};

output = Size of struct is : 8

2) struct data
{
  char arr[10];
  int x;
};

output = Size of struct is : 16

3) struct data
{
  char arr[10];
  long int x;
};

output = Size of struct is : 16

4) struct data
{
  char arr[100];
  int x;
};

output = Size of struct is : 104
// Constructors and Destructors 1 hands-on assignments

a) Point

-> The suitable constructor is Default Constructor

b) Queue

->The suitable constructor is Parameterized Constructor

c)Employee

->The suitable constructor is Copy Constructor

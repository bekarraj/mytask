//NAMESPACE....1
/*#include <iostream>
using namespace std;
namespace ns{
    int x;
}

int main()
{
    int x=9;
    using namespace ns;
    x=20;
    
    cout<<x<<endl;

    return 0;
}*/
//output:
20
//RTTI....5

/*#include <iostream>
#include<typeinfo>

using namespace std;
int a;
char b;
char *pc;
char buf[100];

int main()
{
cout<<typeid(a).name()<<endl;
cout<<typeid(b).name()<<endl; 
cout<<typeid(&b).name()<<endl; 

return 0;
}*/
//output:
i
c
pc
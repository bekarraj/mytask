//RTTI....3

/*#include <iostream>
using namespace std;

class Circle{};
class Shape{};
int main()
{
    Shape* pShape = new Circle;
    Circle *pCircle = dynamic_cast pShape;
    pShape = new Rect;
    pCircle = dynamic_cast pShape;

    pShape head = createShape(Circle);
    pShape body = createShape(Rect);

   return 0;
}*/

//output:
Highlighted statement will not be executed.
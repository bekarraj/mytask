#include<iostream>
using namespace std;
int main()
{
	int a,b;
	cout<<"Enter the numbers:"<<endl;
	cin>>a>>b;
	cout<<"Sum of the two numbers is "<<a+b<<endl;
	cout<<"Difference of the two numbers is "<<a-b<<endl;
	return 0;
}
#include<iostream>
using namespace std;
int main()
{
    int a,b,c,d,e;
    cout<<"Enter 5 numbers: ";
    cin>>a>>b>>c>>d>>e;
    cout<<"Average: "<<(a+b+c+d+e)/5;
    return 0;
}
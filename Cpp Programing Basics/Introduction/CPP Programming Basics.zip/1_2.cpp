#include<iostream>
using namespace std;
int main()
{
	int a,b,c;
	cout<<"Enter the three numbers: ";
	cin>>a>>b>>c;
	cout<<"\nThe numbers are: "<<a<<" "<<b<<" "<<c<<endl;
	return 0;
}
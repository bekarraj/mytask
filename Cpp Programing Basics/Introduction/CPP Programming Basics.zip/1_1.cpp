#include <iostream>
using namespace std;
int main()
{
    cout<<"Welcome to Wipro";
    return 0;
}
#include<iostream>
using namespace std;
int main()
{
	float a,b,c,d,e;
	cout<<"Enter 5 float values: ";
	cin>>a>>b>>c>>d>>e;
	cout<<"\nYou have entered: "<<a<<" "<<b<<" "<<c<<" "<<d<<" "<<e<<endl;
	return 0;
}
// String 14 program

int main()
{
	char *ptr = "uvwxyzabc";
	cout<< 2[ptr];
	cout<< ptr[2];
	cout<< *(ptr + 2);
    return 0;
}

Output = www